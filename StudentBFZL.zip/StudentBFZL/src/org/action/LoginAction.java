package org.action;

import java.util.Map;

import org.dao.DlDao;
import org.model.Dlb;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {
 private Dlb loginJsp_dlb;
 private Dlb mainJsp_user;
 private DlDao dlb;
public Dlb getLoginJsp_dlb() {
	return loginJsp_dlb;
}

public void setLoginJsp_dlb(Dlb loginJsp_dlb) {
	this.loginJsp_dlb = loginJsp_dlb;
}
public Dlb getMainJsp_user() {
	return mainJsp_user;
}

public void setMainJsp_user(Dlb mainJsp_user) {
	this.mainJsp_user = mainJsp_user;
}
@Override
public String execute() throws Exception {
	Dlb user=dlb.validate(loginJsp_dlb.getXh(), loginJsp_dlb.getKl());
	if(user!=null){
		mainJsp_user=user;
		//将登录用户对象放置jsp的session对象中
	    Map session=ActionContext.getContext().getSession();
	    session.put("dlUser", user);
		return "success";}
	else
		return "error";
}

public DlDao getDlb() {
	return dlb;
}

public void setDlb(DlDao dlb) {
	this.dlb = dlb;
}



}
