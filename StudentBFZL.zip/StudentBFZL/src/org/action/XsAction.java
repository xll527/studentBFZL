package org.action;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.dao.KcDao;
import org.dao.XsDao;
import org.dao.ZyDao;
import org.model.Dlb;
import org.model.Kcb;
import org.model.Xsb;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class XsAction extends ActionSupport {
     //新增XsDao和user变量，只在构造函数中使用，不做页面变量的显示
	//因此不需要生成getter和setter
	private XsDao xsDao;
	public XsDao getXsDao() {
		return xsDao;
	}

	public void setXsDao(XsDao xsDao) {
		this.xsDao = xsDao;
	}

	public ZyDao getZyDao() {
		return zyDao;
	}

	public void setZyDao(ZyDao zyDao) {
		this.zyDao = zyDao;
	}

	public KcDao getKcdao() {
		return kcdao;
	}

	public void setKcdao(KcDao kcdao) {
		this.kcdao = kcdao;
	}
	private Dlb user;
	private Xsb xsInfoJsp_xs;
	private Xsb updateXsInfoJsp_xs;
	private List updateXsInfoJsp_zys;
	private Xsb updateActionXs;
	private ZyDao zyDao;
	private List allKcJsp_kcs;
	private KcDao kcdao;
	private Kcb selectActionKcb;
	private Set xsKcsJsp_kcs;
	private Kcb deleteActionKcb;
	
	public XsAction(){
		//首先从jsp的session中获得来LoginAction中put的登录用户对象dlUser
		Map session=ActionContext.getContext().getSession();
		user=(Dlb) session.get("dlUser");
	}
	
	public List getUpdateXsInfoJsp_zys() {
		return updateXsInfoJsp_zys;
	}

	public void setUpdateXsInfoJsp_zys(List updateXsInfoJsp_zys) {
		this.updateXsInfoJsp_zys = updateXsInfoJsp_zys;
	}

	@Override
	public String execute() throws Exception {
		Map session=ActionContext.getContext().getSession();
		user=(Dlb) session.get("dlUser");
		xsInfoJsp_xs=xsDao.getOneXs(user.getXh());
		return "success";
	}
   
	public Xsb getXsInfoJsp_xs() {
		return xsInfoJsp_xs;
	}
	public void setXsInfoJsp_xs(Xsb xsInfoJsp_xs) {
		this.xsInfoJsp_xs = xsInfoJsp_xs;
	}

	public Xsb getUpdateXsInfoJsp_xs() {
		return updateXsInfoJsp_xs;
	}

	public void setUpdateXsInfoJsp_xs(Xsb updateXsInfoJsp_xs) {
		this.updateXsInfoJsp_xs = updateXsInfoJsp_xs;
	}
	public Xsb getUpdateActionXs() {
		return updateActionXs;
	}
	public List getAllKcJsp_kcs() {
		return allKcJsp_kcs;
	}

	public void setAllKcJsp_kcs(List allKcJsp_kcs) {
		this.allKcJsp_kcs = allKcJsp_kcs;
	}

	public void setUpdateActionXs(Xsb updateActionXs) {
		this.updateActionXs = updateActionXs;
	}
	
	public Set getXsKcsJsp_kcs() {
		return xsKcsJsp_kcs;
	}

	public void setXsKcsJsp_kcs(Set xsKcsJsp_kcs) {
		this.xsKcsJsp_kcs = xsKcsJsp_kcs;
	}
	public Kcb getSelectActionKcb() {
		return selectActionKcb;
	}

	public void setSelectActionKcb(Kcb selectActionKcb) {
		this.selectActionKcb = selectActionKcb;
	}
	public Kcb getDeleteActionKcb() {
		return deleteActionKcb;
	}

	public void setDeleteActionKcb(Kcb deleteActionKcb) {
		this.deleteActionKcb = deleteActionKcb;
	}
	public String updateXsInfo(){
		Map session=ActionContext.getContext().getSession();
		user=(Dlb) session.get("dlUser");
		updateXsInfoJsp_xs=xsDao.getOneXs(user.getXh());
		updateXsInfoJsp_zys=zyDao.getAll();
		return "success";
	}
    public String updateXs(){
		Map session=ActionContext.getContext().getSession();
		user=(Dlb) session.get("dlUser");
    	Xsb updateXs=xsDao.getOneXs(user.getXh());
    	//然后将网页端的updateActionXs的各个信息赋值给updateXs
    	updateXs.setXm(updateActionXs.getXm());
    	updateXs.setXb(updateActionXs.getXb());
    	updateXs.setCssj(updateActionXs.getCssj());
    	updateXs.setBz(updateActionXs.getBz());
    	updateXs.setZxf(updateActionXs.getZxf());
    	updateXs.setZyb(updateActionXs.getZyb());
    	xsDao.update(updateXs);
    	return "success";
    }
    public String getAllKc(){
    	allKcJsp_kcs=kcdao.getAll();
    	return "success";
    }
    public String selectKc(){
		Map session=ActionContext.getContext().getSession();
		user=(Dlb) session.get("dlUser");
    	Xsb xs=xsDao.getOneXs(user.getXh());
    	//获取该学生已选的课程集合
    	Set existedKcs=xs.getKcs();
    	/*迭代器查找是否存在待选修的课程编号，如果已存在，则返回error*/
    	Iterator it=existedKcs.iterator();
    	while(it.hasNext()){
    		Kcb kcb=(Kcb)it.next();
    		if(kcb.getKch().trim().equals(selectActionKcb.getKch()))
    		return "error";
    	}
    	//根据课程编号获得课程对象
    	selectActionKcb=kcdao.getOneSc(selectActionKcb.getKch());
    	//添加新的课程到已选的课程集合
    	existedKcs.add(selectActionKcb);
    	//更新
    	xs.setKcs(existedKcs);
    	xsDao.update(xs);
    	return "success";
    }
    public String getXsKcs(){
		Map session=ActionContext.getContext().getSession();
		user=(Dlb) session.get("dlUser");
    	Xsb xs=xsDao.getOneXs(user.getXh());
    	xsKcsJsp_kcs=xs.getKcs();
    	return "success";
    	
    }
    public String deleteKc(){
		Map session=ActionContext.getContext().getSession();
		user=(Dlb) session.get("dlUser");
    	Xsb xs=xsDao.getOneXs(user.getXh());
    	//获得该学生的已选课程集合
    	Set updateKcs=xs.getKcs();
    	Iterator it=updateKcs.iterator();
    	while(it.hasNext()){
    		Kcb kc=(Kcb) it.next();
    		if(kc.getKch().trim().equals(deleteActionKcb.getKch()))
    			it.remove();
    	}
    	xs.setKcs(updateKcs);
    	xsDao.update(xs);
    	return "success";
    }


	

	
}
