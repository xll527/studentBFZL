package org.dao;

import org.model.Dlb;

public interface DlDao {
 public Dlb validate(String xh,String kl);
}
