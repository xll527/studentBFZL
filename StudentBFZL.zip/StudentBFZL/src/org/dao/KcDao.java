package org.dao;

import java.util.List;

import org.model.Kcb;

public interface KcDao {
	//根据编号查询某个课程信息
   public Kcb getOneSc(String kch);
   //查询所有课程信息
   public List getAll();
}
