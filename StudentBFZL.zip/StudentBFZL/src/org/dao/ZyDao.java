package org.dao;

import java.util.List;

import org.model.Zyb;

public interface ZyDao {
	//根据编号查询某个专业信息
    public Zyb getOneZy(Integer id);
    //查询所有专业信息
    public List getAll();
}
