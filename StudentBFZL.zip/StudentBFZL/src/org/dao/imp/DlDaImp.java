package org.dao.imp;

import java.util.List;

import org.dao.DlDao;
import org.model.Dlb;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class DlDaImp extends HibernateDaoSupport implements DlDao {

	public Dlb validate(String xh, String kl) {
		String strs[]={xh,kl};
		List list=this.getHibernateTemplate().find("from org.model.Dlb where xh=? and kl=?",strs);
		if(list.size()>0)
			return (Dlb) list.get(0);
		else
			return null;
	}

}
