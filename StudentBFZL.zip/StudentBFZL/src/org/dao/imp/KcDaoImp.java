package org.dao.imp;

import java.util.List;

import org.dao.KcDao;
import org.model.Kcb;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class KcDaoImp extends HibernateDaoSupport implements KcDao {

	public Kcb getOneSc(String kch) {
         List list=this.getHibernateTemplate().find("from Kcb where kch=?", kch);
         if(list.size()>0)
        	 return (Kcb) list.get(0);
         else
        	 return null;
	}

	public List getAll() {
	    List list=this.getHibernateTemplate().find("from Kcb");
	    return list;
	}

}
