package org.dao.imp;

import java.util.List;

import org.dao.XsDao;
import org.model.Xsb;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class XsDaoImp extends HibernateDaoSupport implements XsDao {

	public Xsb getOneXs(String xh) {
         List list=this.getHibernateTemplate().find("from Xsb where xh=?",xh);
         if(list.size()>0)
        	 return (Xsb) list.get(0);
         else
        	 return null;
	}

	public void update(Xsb xs) {
		getHibernateTemplate().update(xs);
	}

}
