package org.dao.imp;

import java.util.List;

import org.dao.ZyDao;
import org.model.Zyb;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class ZyDaoImp extends HibernateDaoSupport implements ZyDao {

	public Zyb getOneZy(Integer id) {
		List list=this.getHibernateTemplate().find("from Zyb where id=?", id);
		if(list.size()>0)
			return (Zyb) list.get(0);
		else 
			return null;
	}

	public List getAll() {
		List list=this.getHibernateTemplate().find("from Zyb");
		return list;
	}

}
