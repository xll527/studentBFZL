package org.model;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * Xsb entity. @author MyEclipse Persistence Tools
 */

public class Xsb implements java.io.Serializable {

	// Fields

	private String xh;
	private Zyb zyb;
	private String xm;
	private Byte xb;
	private Date cssj;
	private Integer zxf;
	private String bz;
	private byte[] zp;
    private Set kcs=new HashSet(0);
	// Constructors

	public Set getKcs() {
		return kcs;
	}

	public void setKcs(Set kcs) {
		this.kcs = kcs;
	}

	/** default constructor */
	public Xsb() {
	}

	/** minimal constructor */
	public Xsb(String xh) {
		this.xh = xh;
	}

	/** full constructor */
	public Xsb(String xh, Zyb zyb, String xm, Byte xb, Date cssj,
			Integer zxf, String bz, byte[] zp) {
		this.xh = xh;
		this.zyb = zyb;
		this.xm = xm;
		this.setXb(xb);
		this.setCssj(cssj);
		this.zxf = zxf;
		this.bz = bz;
		this.setZp(zp);
	}

	// Property accessors

	public String getXh() {
		return this.xh;
	}

	public void setXh(String xh) {
		this.xh = xh;
	}

	public Zyb getZyb() {
		return this.zyb;
	}

	public void setZyb(Zyb zyb) {
		this.zyb = zyb;
	}

	public String getXm() {
		return this.xm;
	}

	public void setXm(String xm) {
		this.xm = xm;
	}



	public Integer getZxf() {
		return this.zxf;
	}

	public void setZxf(Integer zxf) {
		this.zxf = zxf;
	}

	public String getBz() {
		return this.bz;
	}

	public void setBz(String bz) {
		this.bz = bz;
	}

	public Byte getXb() {
		return xb;
	}

	public void setXb(Byte xb) {
		this.xb = xb;
	}

	public Date getCssj() {
		return cssj;
	}

	public void setCssj(Date cssj) {
		this.cssj = cssj;
	}

	public byte[] getZp() {
		return zp;
	}

	public void setZp(byte[] zp) {
		this.zp = zp;
	}

	

}