package org.test;

import org.dao.DlDao;
import org.dao.XsDao;
import org.dao.ZyDao;
import org.model.Dlb;
import org.model.Xsb;
import org.model.Zyb;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		 ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		 ZyDao xsdao=(ZyDao) context.getBean("ZyDaoImp");
		 Zyb xs=xsdao.getOneZy(1);
		 if(xs!=null)
			 System.out.println("存在该用户");
		 else
			 System.out.println("无该用户");
	}

}
